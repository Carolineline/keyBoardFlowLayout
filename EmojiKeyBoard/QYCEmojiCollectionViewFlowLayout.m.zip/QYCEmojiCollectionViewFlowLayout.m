//
//  QYCEmojiCollectionViewFlowLayout.m
//  
//
//  Created by 晓琳 on 17/3/13.
//
//

#import "QYCEmojiCollectionViewFlowLayout.h"

@interface QYCEmojiCollectionViewFlowLayout ()

@property (nonatomic, strong) NSMutableArray *allAttributes;
// 一行中 cell的个数
@property (nonatomic) NSUInteger itemCountPerRow;
// 一页显示多少行
@property (nonatomic) NSUInteger rowCount;

@end
@implementation QYCEmojiCollectionViewFlowLayout

- (void)prepareLayout
{
    [super prepareLayout];
    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.allAttributes = [NSMutableArray array];
    self.itemCountPerRow = 8;
    self.rowCount = 3;
//    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    NSInteger sections = [self.collectionView numberOfSections];
    for (int i = 0; i < sections; i++){
        NSMutableArray * tmpArray = [NSMutableArray array];
        NSUInteger count = [self.collectionView numberOfItemsInSection:i];
        
        for (NSUInteger j = 0; j<count; j++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:j inSection:i];
            UICollectionViewLayoutAttributes *attributes = [self layoutAttributesForItemAtIndexPath:indexPath];
            [tmpArray addObject:attributes];
        }
        
        [self.allAttributes addObject:tmpArray];
    }
}

- (CGSize)collectionViewContentSize
{
    return [super collectionViewContentSize];
}

- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect
{
//    return self.allAttributes;
    
    NSArray *attributes = [super layoutAttributesForElementsInRect:rect];
    
    NSMutableArray *tmp = [NSMutableArray array];
    
    for (UICollectionViewLayoutAttributes *attr in attributes) {
        NSLog(@"1111 = %@",attr);
        UICollectionViewLayoutAttributes *attr2 = [self targetPositionWithItem:attr.indexPath];
        NSLog(@"2222 = %@",attr);
        NSLog(@"3333 = %@",attr2);
        [tmp addObject:attr2];

    }
    return tmp;
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return YES;
}

- (UICollectionViewLayoutAttributes *)targetPositionWithItem:(NSIndexPath *)index
{
    if (!index) {
        return nil;
    }
    NSUInteger page = index.section;
    
    CGFloat theX = (index.row % self.itemCountPerRow + page * self.itemCountPerRow) * 30 + 30 + 95.0/7*(index.row%8);
    CGFloat theY = (index.row / self.itemCountPerRow - page * self.rowCount) * 40 + 25;
    UICollectionViewLayoutAttributes *attr = [self layoutAttributesForItemAtIndexPath:index];
    attr.frame = CGRectMake(theX, theY, 30, 30);
    return attr;
}


@end
